# Bahmni OPD Demo

A standalone OPD interface built with HTML, CSS, and JavaScript.

## Folder structure

bahmni-opd/
- index.html
- css/style.css
- js/app.js
- js/patients.js
- js/registration.js
- js/queue.js
- js/consultation.js
- js/reports.js
- assets/images/logo.png
- assets/icons/
- README.md

## How to run

Open `index.html` in a modern web browser.

## Features

- OPD dashboard
- Patient registration
- Patient search
- OPD queue
- Consultation entry
- Vital signs
- Diagnosis and treatment
- Patient statistics
- Print report
- Browser localStorage data persistence

## Important

This is a standalone demonstration application. It is NOT connected to an OpenMRS/Bahmni backend.

Do not use real patient information in this demo. A production clinical system requires authentication, authorization, encryption, secure server/database storage, audit logging, backups, privacy controls, and proper integration with the Bahmni/OpenMRS environment.

## JavaScript modules

The current working implementation is kept in `js/app.js`. The other JavaScript files are reserved for future modularization:
- patients.js
- registration.js
- queue.js
- consultation.js
- reports.js
