let patients = JSON.parse(localStorage.getItem("opdPatients")) || [];

function saveData() {
  localStorage.setItem("opdPatients", JSON.stringify(patients));
}

function showPage(page, element) {
  document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
  const target = document.getElementById(page);
  if (target) target.classList.add("active");

  document.querySelectorAll("aside a").forEach(a => a.classList.remove("active"));
  if (element) element.classList.add("active");

  refreshAll();
}

function registerPatient(event) {
  event.preventDefault();

  const patient = {
    id: "OPD-" + Date.now().toString().slice(-6),
    firstName: document.getElementById("firstName").value.trim(),
    lastName: document.getElementById("lastName").value.trim(),
    age: document.getElementById("age").value,
    sex: document.getElementById("sex").value,
    phone: document.getElementById("phone").value.trim(),
    address: document.getElementById("address").value.trim(),
    status: "Waiting",
    registeredAt: new Date().toLocaleString(),
    consultation: null
  };

  patients.push(patient);
  saveData();

  alert("Patient registered successfully.\nPatient ID: " + patient.id);
  event.target.reset();
  refreshAll();
}

function renderPatients(list = patients) {
  const table = document.getElementById("patientsTable");
  table.innerHTML = "";

  if (!list.length) {
    table.innerHTML = '<tr><td colspan="6" class="empty">No patients found.</td></tr>';
    return;
  }

  list.forEach(p => {
    table.innerHTML += `
      <tr>
        <td>${escapeHTML(p.id)}</td>
        <td>${escapeHTML(p.firstName + " " + p.lastName)}</td>
        <td>${escapeHTML(p.age)}</td>
        <td>${escapeHTML(p.sex)}</td>
        <td>${escapeHTML(p.phone || "-")}</td>
        <td><span class="badge">${escapeHTML(p.status)}</span></td>
      </tr>`;
  });
}

function searchPatients() {
  const q = document.getElementById("searchPatient").value.toLowerCase().trim();
  renderPatients(
    patients.filter(p =>
      (p.firstName + " " + p.lastName + " " + p.id + " " + (p.phone || ""))
        .toLowerCase()
        .includes(q)
    )
  );
}

function renderQueue() {
  const table = document.getElementById("queueTable");
  table.innerHTML = "";

  const waiting = patients.filter(p => p.status === "Waiting");

  if (!waiting.length) {
    table.innerHTML = '<tr><td colspan="5" class="empty">OPD queue is empty.</td></tr>';
    return;
  }

  waiting.forEach((p, index) => {
    table.innerHTML += `
      <tr>
        <td>${index + 1}</td>
        <td>${escapeHTML(p.firstName + " " + p.lastName)}</td>
        <td>${escapeHTML(p.id)}</td>
        <td><span class="badge">${escapeHTML(p.status)}</span></td>
        <td><button class="action-btn" onclick="startConsultation('${escapeJS(p.id)}')">Consult</button></td>
      </tr>`;
  });
}

function startConsultation(id) {
  const patient = patients.find(p => p.id === id);
  if (!patient) return;

  patient.status = "Consultation";
  saveData();

  document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
  document.getElementById("consultation").classList.add("active");

  populateConsultPatients();
  document.getElementById("consultPatient").value = id;
  refreshAll();
}

function populateConsultPatients() {
  const select = document.getElementById("consultPatient");
  const current = select.value;

  select.innerHTML = '<option value="">Select Patient</option>';

  patients
    .filter(p => p.status !== "Completed")
    .forEach(p => {
      select.innerHTML += `
        <option value="${escapeHTML(p.id)}">
          ${escapeHTML(p.id)} - ${escapeHTML(p.firstName + " " + p.lastName)}
        </option>`;
    });

  if (patients.some(p => p.id === current && p.status !== "Completed")) {
    select.value = current;
  }
}

function saveConsultation() {
  const id = document.getElementById("consultPatient").value;

  if (!id) {
    alert("Please select patient.");
    return;
  }

  const patient = patients.find(p => p.id === id);
  if (!patient) return;

  patient.consultation = {
    complaint: document.getElementById("complaint").value.trim(),
    bp: document.getElementById("bp").value.trim(),
    pulse: document.getElementById("pulse").value.trim(),
    temperature: document.getElementById("temperature").value.trim(),
    spo2: document.getElementById("spo2").value.trim(),
    notes: document.getElementById("notes").value.trim(),
    diagnosis: document.getElementById("diagnosis").value.trim(),
    treatment: document.getElementById("treatment").value.trim(),
    date: new Date().toLocaleString()
  };

  patient.status = "Completed";
  saveData();

  alert("Consultation saved successfully.");
  clearConsultationForm();
  refreshAll();
}

function clearConsultationForm() {
  document.getElementById("complaint").value = "";
  document.getElementById("bp").value = "";
  document.getElementById("pulse").value = "";
  document.getElementById("temperature").value = "";
  document.getElementById("spo2").value = "";
  document.getElementById("notes").value = "";
  document.getElementById("diagnosis").value = "";
  document.getElementById("treatment").value = "";
  document.getElementById("consultPatient").value = "";
}

function updateDashboard() {
  document.getElementById("todayPatients").textContent = patients.length;
  document.getElementById("waitingPatients").textContent =
    patients.filter(p => p.status === "Waiting").length;
  document.getElementById("completedPatients").textContent =
    patients.filter(p => p.status === "Completed").length;
  document.getElementById("newPatients").textContent =
    patients.filter(p => p.status === "Waiting").length;

  const table = document.getElementById("dashboardTable");
  table.innerHTML = "";

  const recent = patients.slice(-10).reverse();

  if (!recent.length) {
    table.innerHTML = '<tr><td colspan="5" class="empty">No patients registered yet.</td></tr>';
    return;
  }

  recent.forEach(p => {
    table.innerHTML += `
      <tr>
        <td>${escapeHTML(p.id)}</td>
        <td>${escapeHTML(p.firstName + " " + p.lastName)}</td>
        <td>${escapeHTML(p.age)}</td>
        <td>${escapeHTML(p.sex)}</td>
        <td><span class="badge">${escapeHTML(p.status)}</span></td>
      </tr>`;
  });
}

function updateReports() {
  document.getElementById("reportTotal").textContent = patients.length;
  document.getElementById("reportMale").textContent =
    patients.filter(p => p.sex === "Male").length;
  document.getElementById("reportFemale").textContent =
    patients.filter(p => p.sex === "Female").length;
}

function escapeHTML(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function escapeJS(value) {
  return String(value ?? "").replace(/\\/g, "\\\\").replace(/'/g, "\\'");
}

function refreshAll() {
  renderPatients();
  renderQueue();
  populateConsultPatients();
  updateDashboard();
  updateReports();
}

refreshAll();
