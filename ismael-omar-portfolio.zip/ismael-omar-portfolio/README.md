# Ismael Omar — Portfolio Website

A responsive React + Vite personal portfolio with a dark purple gradient and yellow accent style.

## Run locally
1. Install Node.js (18 or newer).
2. Open this project folder in a terminal.
3. Run `npm install`.
4. Run `npm run dev` and open the local URL shown.

## Deploy to Vercel
1. Create a GitHub repository and upload this project.
2. Sign in at https://vercel.com and choose **Add New → Project**.
3. Import the GitHub repository.
4. Vercel should detect Vite automatically. Build command: `npm run build`; output directory: `dist`.
5. Select **Deploy**. Vercel assigns a free `*.vercel.app` address.

## Personalize before publishing
- In `src/main.jsx`, replace `ismael.omar@example.com` with your real email.
- Replace the LinkedIn and GitHub profile links with your own URLs.
- Replace the three sample project cards with your real projects.
- Add your own profile photo if desired.

No API keys or secrets are needed for this static portfolio.
