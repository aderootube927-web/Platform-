import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  ArrowUpRight, Code2, Menu, X, Eye, Mail, Linkedin, Github, BriefcaseBusiness,
  Sparkles, BrainCircuit, Smartphone, Globe2, Layers3, ChevronRight
} from 'lucide-react';
import './styles.css';

const projects = [
  { number: '01', type: 'HEALTH TECHNOLOGY', title: 'Digital Health Platform', description: 'A concept for connecting patient registration, appointments, clinical workflows and health reporting in one clear experience.', tags: ['React', 'Digital Health', 'UX'] },
  { number: '02', type: 'AI & MACHINE LEARNING', title: 'AI Assistant Experience', description: 'An intelligent assistant concept designed to make information easier to explore and everyday tasks simpler.', tags: ['AI', 'Automation', 'Product'] },
  { number: '03', type: 'WEB APPLICATION', title: 'Business Web Platform', description: 'A responsive web product concept with a focused dashboard, account experience and engaging interactive features.', tags: ['Web', 'Dashboard', 'Responsive'] }
];

const skills = [
  ['Frontend Development', 'React, JavaScript, responsive interfaces'],
  ['AI & Machine Learning', 'AI concepts, intelligent workflows'],
  ['Backend & APIs', 'Application logic, API integration'],
  ['Product Thinking', 'User-focused design and problem solving']
];

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const closeMenu = () => setMenuOpen(false);
  const email = 'ismael.omar@example.com'; // Replace with your real email.
  return (
    <>
      <header className="topbar">
        <a className="brand" href="#home" onClick={closeMenu}><span className="brand-mark"><Code2 size={25}/></span> Ismael Omar<span className="brand-dot">.</span></a>
        <button className="menu-toggle" aria-label="Toggle navigation" onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X/> : <Menu/>}</button>
        <nav className={menuOpen ? 'nav open' : 'nav'}>
          {['Home','About','Skills','Projects','Services','Contact'].map(x => <a key={x} href={`#${x.toLowerCase()}`} onClick={closeMenu}>{x}</a>)}
        </nav>
      </header>

      <main>
        <section className="hero" id="home">
          <div className="hero-glow glow-one"></div><div className="hero-glow glow-two"></div>
          <div className="hero-inner">
            <div className="hero-copy">
              <div className="eyebrow"><span className="status-dot"></span> AVAILABLE FOR OPPORTUNITIES</div>
              <h1>Building digital<br/>experiences with <span>purpose.</span></h1>
              <p className="role">Software Developer <i>&</i> AI Engineer</p>
              <p className="intro">Hello, I'm <strong>Ismael Omar</strong>. I create thoughtful software experiences and explore how AI can solve real-world problems.</p>
              <div className="hero-actions">
                <a className="btn btn-primary" href="#projects"><Eye size={19}/> View My Work</a>
                <a className="btn btn-outline" href="#contact"><Mail size={19}/> Get In Touch</a>
              </div>
              <div className="socials">
                <a href="https://www.linkedin.com/" target="_blank" rel="noreferrer" aria-label="LinkedIn"><Linkedin/></a>
                <a href="https://github.com/" target="_blank" rel="noreferrer" aria-label="GitHub"><Github/></a>
                <a href="#projects" aria-label="Portfolio projects"><BriefcaseBusiness/></a>
                <a href={`mailto:${email}`} aria-label="Email"><Mail/></a>
              </div>
            </div>
            <div className="hero-art" aria-label="Ismael Omar initials graphic">
              <div className="orbit orbit-a"></div><div className="orbit orbit-b"></div>
              <div className="profile-circle"><span>IO</span><small>SOFTWARE · AI</small></div>
              <div className="float-card card-code"><Code2 size={18}/><span>Clean code</span></div>
              <div className="float-card card-ai"><Sparkles size={18}/><span>AI ideas</span></div>
              <div className="art-caption">Curious mind. Practical solutions.</div>
            </div>
          </div>
          <a className="scroll-cue" href="#about"><span></span> SCROLL TO EXPLORE</a>
        </section>

        <section className="section about-section" id="about">
          <div className="section-kicker">01 / ABOUT ME</div>
          <div className="about-grid">
            <h2>Technology is most powerful when it <span>helps people.</span></h2>
            <div className="about-text"><p>I'm Ismael Omar, a Software Developer and AI Engineer interested in building useful, accessible and reliable digital products. I enjoy turning complex ideas into simple experiences.</p><p>This portfolio is a growing showcase of my interests, skills and project work. Explore the sections below and feel free to get in touch.</p><a className="text-link" href="#contact">Let's connect <ArrowUpRight size={17}/></a></div>
          </div>
          <div className="stats-row"><div><strong>01</strong><span>Curiosity first</span></div><div><strong>∞</strong><span>Always learning</span></div><div><strong>100%</strong><span>Focused on growth</span></div></div>
        </section>

        <section className="section skills-section" id="skills">
          <div className="section-kicker">02 / WHAT I DO</div>
          <div className="section-heading"><h2>Skills & <span>expertise</span></h2><p>A mix of engineering, creative thinking and continuous learning.</p></div>
          <div className="skills-grid">{skills.map(([title, desc], i) => <article className="skill-card" key={title}><div className="skill-icon">{[<Code2/>,<BrainCircuit/>,<Layers3/>,<Globe2/>][i]}</div><div className="skill-num">0{i+1}</div><h3>{title}</h3><p>{desc}</p><ChevronRight className="skill-arrow"/></article>)}</div>
        </section>

        <section className="section projects-section" id="projects">
          <div className="section-kicker">03 / SELECTED WORK</div>
          <div className="section-heading"><h2>Ideas into <span>projects.</span></h2><p>Selected project concepts and areas of interest. Replace these examples with your completed work.</p></div>
          <div className="projects-grid">{projects.map(p => <article className="project-card" key={p.number}><div className="project-top"><span>{p.type}</span><b>{p.number}</b></div><div className="project-visual"><div className="visual-window"><div className="window-dots"><i/><i/><i/></div><div className="visual-lines"><span/><span/><span/></div><div className="visual-orb"><Sparkles/></div></div></div><h3>{p.title}</h3><p>{p.description}</p><div className="tags">{p.tags.map(t => <span key={t}>{t}</span>)}</div></article>)}</div>
        </section>

        <section className="section services-section" id="services">
          <div className="section-kicker">04 / SERVICES</div>
          <div className="section-heading"><h2>How I can <span>help.</span></h2><p>Areas where I’m building expertise and can collaborate.</p></div>
          <div className="services-list">
            <div><span>01</span><Code2/><h3>Web Development</h3><p>Responsive, user-friendly websites and web applications.</p><ArrowUpRight/></div>
            <div><span>02</span><BrainCircuit/><h3>AI Solutions</h3><p>Exploring practical AI integrations and smart workflows.</p><ArrowUpRight/></div>
            <div><span>03</span><Smartphone/><h3>Digital Products</h3><p>Thoughtful product experiences across devices.</p><ArrowUpRight/></div>
          </div>
        </section>

        <section className="contact-section" id="contact">
          <div className="contact-orb"></div><div className="section-kicker">05 / GET IN TOUCH</div>
          <h2>Have an idea?<br/><span>Let's build it.</span></h2>
          <p>I'm open to conversations, collaboration and learning opportunities.</p>
          <a className="btn btn-primary contact-btn" href={`mailto:${email}?subject=Hello%20Ismael`}><Mail size={19}/> Say Hello <ArrowUpRight size={18}/></a>
          <div className="contact-note">Replace the sample email and social links with your own details.</div>
        </section>
      </main>
      <footer><a className="brand" href="#home"><span className="brand-mark"><Code2 size={20}/></span> Ismael Omar<span className="brand-dot">.</span></a><span>Designed with curiosity · © {new Date().getFullYear()} Ismael Omar</span><a href="#home" className="back-top">Back to top ↑</a></footer>
    </>
  );
}

createRoot(document.getElementById('root')).render(<App />);